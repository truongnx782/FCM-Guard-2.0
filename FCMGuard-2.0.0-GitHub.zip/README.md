# FCM Guard 2.0

FCM Guard is a lightweight HyperOS/Android helper focused on reliable push notifications without keeping a foreground service alive 24/7.

## Design

- No permanent foreground service.
- No WakeLock.
- No root.
- No Accessibility Service.
- No Notification Listener.
- No polling of Google Play Services.
- Uses WorkManager for a lightweight periodic health check.
- Provides direct paths to Android/Xiaomi settings.
- Checks whether Google Play Services and Google Services Framework are installed.
- Requests notification permission for Android 13+.
- Can request battery-optimization exemption for FCM Guard itself.

## Important limitation

A normal Android app cannot directly force `com.google.android.gms` to remain alive or guarantee another app's FCM connection. The app therefore optimizes the conditions that can be controlled through public Android APIs and Xiaomi settings.

For the best FCM delivery, the application receiving FCM should send genuinely user-visible time-sensitive notifications as HIGH priority. Normal priority is more battery-friendly but can be delayed during Doze.

## Build

The included GitHub Actions workflow builds a debug APK without requiring a PC.
