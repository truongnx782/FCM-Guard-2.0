# FCM Guard does not require custom shrinking rules.
