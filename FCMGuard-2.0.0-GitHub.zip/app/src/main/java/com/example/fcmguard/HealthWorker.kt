package com.example.fcmguard

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class HealthWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        // Deliberately lightweight:
        // no WakeLock, no polling, no starting GMS, no network request.
        val pm = applicationContext.packageManager
        val gms = try {
            pm.getApplicationInfo("com.google.android.gms", 0)
            true
        } catch (_: Exception) {
            false
        }
        return if (gms) Result.success() else Result.retry()
    }
}
