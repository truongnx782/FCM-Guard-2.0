package com.example.fcmguard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.WorkManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var root: LinearLayout
    private lateinit var statusContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestNotificationPermission()
        scheduleHealthCheck()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::statusContainer.isInitialized) refresh()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(20))
            setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.surface))
        }

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        val title = TextView(this).apply {
            text = getString(R.string.app_title)
            textSize = 30f
            setTextColor(0xFF111827.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = getString(R.string.app_subtitle)
            textSize = 15f
            setTextColor(0xFF667085.toInt())
            setPadding(0, dp(4), 0, dp(20))
        }
        root.addView(subtitle)

        val card = MaterialCardView(this).apply {
            radius = dp(16).toFloat()
            cardElevation = 0f
            setCardBackgroundColor(0xFFFFFFFF.toInt())
        }

        statusContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        card.addView(statusContainer)
        root.addView(card, lp(0, 0, 1f, dp(12)))

        val fix = MaterialButton(this).apply {
            text = getString(R.string.fix_button)
            textSize = 16f
            setOnClickListener { optimize() }
        }
        root.addView(fix, lp(0, 0, 1f, dp(10)))

        val settings = MaterialButton(this).apply {
            text = getString(R.string.settings_button)
            setOnClickListener { openXiaomiSettings() }
        }
        root.addView(settings, lp(0, 0, 1f, dp(10)))

        val battery = MaterialButton(this).apply {
            text = getString(R.string.battery_button)
            setOnClickListener { requestIgnoreBatteryOptimization() }
        }
        root.addView(battery, lp(0, 0, 1f, dp(10)))

        val test = MaterialButton(this).apply {
            text = getString(R.string.test_button)
            setOnClickListener { refresh() }
        }
        root.addView(test, lp(0, 0, 1f, dp(16)))

        val footer = TextView(this).apply {
            text = getString(R.string.footer)
            textSize = 13f
            setTextColor(0xFF667085.toInt())
        }
        root.addView(footer)
    }

    private fun refresh() {
        statusContainer.removeAllViews()

        addStatus(
            getString(R.string.gms_label),
            if (isInstalled("com.google.android.gms")) "ĐÃ CÀI" else "KHÔNG TÌM THẤY",
            isInstalled("com.google.android.gms")
        )

        addStatus(
            getString(R.string.gsf_label),
            if (isInstalled("com.google.android.gsf")) "ĐÃ CÀI" else "KHÔNG TÌM THẤY",
            isInstalled("com.google.android.gsf")
        )

        val notificationsOk = Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        addStatus(
            getString(R.string.notification_label),
            if (notificationsOk) "ĐÃ CẤP" else "CHƯA CẤP",
            notificationsOk
        )

        val pm = getSystemService(PowerManager::class.java)
        val batteryOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                pm.isIgnoringBatteryOptimizations(packageName)
        addStatus(
            getString(R.string.battery_label),
            if (batteryOk) "KHÔNG HẠN CHẾ" else "ĐANG TỐI ƯU",
            batteryOk
        )

        addStatus(
            getString(R.string.auto_start_label),
            if (isXiaomi()) "CẦN KIỂM TRA" else "KHÔNG PHẢI XIAOMI",
            !isXiaomi()
        )
    }

    private fun addStatus(label: String, value: String, ok: Boolean) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(7), 0, dp(7))
        }

        val left = TextView(this).apply {
            text = label
            textSize = 15f
            setTextColor(0xFF344054.toInt())
        }
        val right = TextView(this).apply {
            text = value
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(if (ok) 0xFF16A34A.toInt() else 0xFFDC2626.toInt())
            gravity = android.view.Gravity.END
        }

        row.addView(left, LinearLayout.LayoutParams(0, dp(30), 1f))
        row.addView(right, LinearLayout.LayoutParams(dp(150), dp(30)))
        statusContainer.addView(row)
    }

    private fun optimize() {
        requestNotificationPermission()
        requestIgnoreBatteryOptimization()
        openXiaomiSettings()
        scheduleHealthCheck()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                100
            )
        }
    }

    private fun requestIgnoreBatteryOptimization() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return

        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Exception) {
                openAppDetails()
            }
        } else {
            openAppDetails()
        }
    }

    private fun openXiaomiSettings() {
        val candidates = listOf(
            Intent("miui.intent.action.OP_AUTO_START").apply {
                addCategory(Intent.CATEGORY_DEFAULT)
            },
            Intent().apply {
                action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                data = Uri.parse("package:$packageName")
            }
        )

        for (intent in candidates) {
            try {
                startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }
        openAppDetails()
    }

    private fun openAppDetails() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                }
            )
        } catch (_: Exception) {
        }
    }

    private fun scheduleHealthCheck() {
        val request = androidx.work.PeriodicWorkRequestBuilder<HealthWorker>(
            6, java.util.concurrent.TimeUnit.HOURS
        ).build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "fcm_guard_health",
            androidx.work.ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    private fun isInstalled(pkg: String): Boolean =
        try {
            packageManager.getApplicationInfo(pkg, 0)
            true
        } catch (_: Exception) {
            false
        }

    private fun isXiaomi(): Boolean =
        Build.MANUFACTURER.lowercase(Locale.ROOT).contains("xiaomi") ||
        Build.MANUFACTURER.lowercase(Locale.ROOT).contains("redmi")

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, weight: Float = 0f, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            if (w == 0) LinearLayout.LayoutParams.MATCH_PARENT else dp(w),
            if (h == 0) LinearLayout.LayoutParams.WRAP_CONTENT else h
        ).apply {
            this.weight = weight
            bottomMargin = bottom
        }
}
